export const keys = {
  HEADER_BUTTONS: "HEADER_BUTTONS",
  APPS: "APPS",
  SETTING: "SETTING",
  DETAILS: "DETAILS",
} as const;
