import { create } from "zustand";

interface UseTheme {
  globalLoading: boolean;
  theme: string;
  setTheme: (name: string) => void;
  setGlobalLoading: (bool: boolean) => void;
}

export const useTheme = create<UseTheme>((set) => ({
  globalLoading: false,
  theme: "dark1",
  setTheme: (name) => set({ theme: name }),
  setGlobalLoading: (bool) => set({ globalLoading: bool }),
}));
